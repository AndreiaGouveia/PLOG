===================== Instruções de execução ==================

Para obter a resolução de um dos puzzles:
1. No sictus consultar o ficheiro 'weight.pl'.
2. Chamar a função wight(X), sendo X=3,5,6,7,8,9,10,14,19 ou 20.

Para gerar um puzzle aleatório e obter a sua resolução:
1. No sictus consultar o ficheiro 'weight.pl'.
2. Chamar a função generate(X,Y), sendo x o nº de pesos e o y, o nº de sub-árvores. É de notar que x tem que ser maior que (y)^2.

Para obter o tempo de execução de um puzzle:
1. No sictus consultar o ficheiro 'weight.pl'.
2. Chamar a função getTime(x), sendo X=3,5,6,7,8,9,10,14,19 ou 20.