:- consult('Menu.pl').
:- consult('display.pl').
:- consult('Logica.pl').

quantik:- menus.